-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-11-2023 a las 04:41:39
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_rrhh`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualiza_empleados` (IN `_codempleado` VARCHAR(100), IN `_nombre` VARCHAR(100), IN `_apellido` VARCHAR(100), IN `_sexo` VARCHAR(100), IN `_estado` TINYINT, IN `_estadocivil` VARCHAR(100), IN `_tiposangre` VARCHAR(100), IN `_direccion` VARCHAR(100), IN `_dui` VARCHAR(100), IN `_fechcontrat` DATE, IN `_fechnac` DATE, IN `_fechterm` DATE, IN `_nombcontacto` VARCHAR(100), IN `_parentcontac` VARCHAR(100), IN `_salario` DOUBLE, IN `_telefo` VARCHAR(100), IN `_telcontac` VARCHAR(100), IN `_depart` VARCHAR(100), IN `_depend` VARCHAR(100), IN `_munic` VARCHAR(100), IN `_puesto` VARCHAR(100), IN `_tipocontra` VARCHAR(100), IN `_correo` VARCHAR(100))   BEGIN 
	UPDATE empleados SET nombre=_nombre,apellidos=_apellido,sexo=_sexo,estado=_estado,direccion=_direccion,dui=_dui,fecha_contratacion=_fechcontrat,fecha_nacimiento=_fechnac,fecha_terminacion=_fechterm,nombre_contacto=_nombcontacto,parentesco_contacto=_parentcontac,salario=_salario,telefono=_telefo,telefono_contacto=_telcontac,correo=_correo WHERE codigo_empleado=_codempleado; 


SELECT id 
INTO @IdEmpleado
from empleados 
WHERE codigo_empleado=_codempleado; 

SELECT id 
INTO @Idestcivil
from estado_civil 
WHERE nombre=_estadocivil; 

SELECT id 
INTO @Idsangre
from tipo_sangre
WHERE tipo=_tiposangre; 

SELECT id 
INTO @Iddepart
from departamentos
WHERE nombre=_depart; 

SELECT id 
INTO @Iddepend
from dependencia
WHERE nombre=_depend; 

SELECT id 
INTO @Idmunic
from municipios
WHERE nombre=_munic; 

SELECT id 
INTO @Idpuesto
from puestos
WHERE nombre=_puesto; 

SELECT id 
INTO @Idtipocontra
from tipo_contrato
WHERE tipo=_tipocontra; 


UPDATE detalle_empleado SET id_estado_civil=@Idestcivil,id_tipo_sangre=@Idsangre,id_departamento=@Iddepart,id_dependencia=@Iddepend,id_municipio=@Idmunic,id_puesto=@Idpuesto,id_tipo_contratacion=@Idtipocontra WHERE id_empleado=@IdEmpleado;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `codemp` ()   BEGIN
 SET @id=(SELECT id FROM empleados order by id desc LIMIT 1);
 SELECT codigo_empleado FROM empleados WHERE id=@id;
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertar_documento` (IN `_codempl` VARCHAR(100), IN `_numerodoc` VARCHAR(100), IN `_tipodoc` VARCHAR(100), IN `_institucion` VARCHAR(100))   BEGIN 
	
SET @idDetalle=(SELECT det.id FROM detalle_empleado det WHERE det.id_empleado=(SELECT emp.id from empleados emp WHERE emp.codigo_empleado=_codempl));
SET @idInstitucion=(SELECT id FROM institucion WHERE nombre=_institucion);
SET @idTipoDoc=(SELECT id FROM tipo_documento WHERE nombre=_tipodoc);

insert into documentos(id_detalle,id_institucion,id_tipo_documento,numero) values(@idDetalle,@idInstitucion,@idTipoDoc,_numerodoc); 


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertar_empleados` (IN `_nombre` VARCHAR(100), IN `_apellido` VARCHAR(100), IN `_sexo` VARCHAR(100), IN `_estado` TINYINT, IN `_createdby` INT, IN `_createdat` DATETIME, IN `_idestadocivil` INT, IN `_idtiposangre` INT, IN `_direccion` VARCHAR(100), IN `_dui` VARCHAR(100), IN `_fechcontrat` DATE, IN `_fechnac` DATE, IN `_fechterm` DATE, IN `_nombcontacto` VARCHAR(100), IN `_parentcontac` VARCHAR(100), IN `_salario` DOUBLE, IN `_telefo` VARCHAR(100), IN `_telcontac` VARCHAR(100), IN `_iddepart` INT, IN `_iddepend` INT, IN `_idmunic` INT, IN `_idpuesto` INT, IN `_idtipocontra` INT, IN `_idusuario` INT, IN `_correo` VARCHAR(100))   BEGIN 
	insert into empleados(nombre,apellidos,sexo,estado,created_by,created_at, direccion, dui, fecha_contratacion, fecha_nacimiento, fecha_terminacion, nombre_contacto, parentesco_contacto, salario,telefono, telefono_contacto,correo) values(_nombre,_apellido,_sexo,_estado,_createdby,_createdat,_direccion,_dui, _fechcontrat, _fechnac,_fechterm, _nombcontacto,_parentcontac,_salario,_telefo,_telcontac,_correo); 

    SET @IdEmpleado=last_insert_id(); 

insert into detalle_empleado( id_empleado,id_estado_civil,id_tipo_sangre,id_departamento,id_dependencia,id_municipio,id_puesto,id_tipo_contratacion,id_usuario) values(@IdEmpleado,_idestadocivil,_idtiposangre,_iddepart,_iddepend,_idmunic,_idpuesto,_idtipocontra,_idusuario);


    IF @idEmpleado<10 THEN
        SET @cod_emp=CONCAT("E000",@idEmpleado);
    ELSEIF	@idEmpleado<100 THEN
        SET @cod_emp=CONCAT("E00",@idEmpleado);
    ELSEIF @idEmpleado<1000 THEN
        SET @cod_emp=CONCAT("E0",@idEmpleado);
    ELSE
        SET @cod_emp=CONCAT("E",@idEmpleado);
    END IF;

    UPDATE empleados SET codigo_empleado=@cod_emp WHERE id=@idEmpleado;



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `verdocumentos` (IN `_codempleado` VARCHAR(100))   BEGIN
 
 SELECT * FROM documentos_view WHERE codigo_empleado=_codempleado;
 END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(191) NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id`, `nombre`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Ahuachapán', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(2, 'Santa Ana', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(3, 'Sonsonate', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(4, 'La Libertad', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(5, 'Chalatenango', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(6, 'San Salvador', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(7, 'Cuscatlán', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(8, 'La Paz', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(9, 'Cabañas', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(10, 'San Vicente', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(11, 'Usulután', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(12, 'Morazán', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(13, 'San Miguel', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57'),
(14, 'La Unión', 1, 1, '2023-04-17 07:05:57', '2023-04-17 07:05:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dependencia`
--

CREATE TABLE `dependencia` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_empleado`
--

CREATE TABLE `detalle_empleado` (
  `id` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `id_tipo_contratacion` int(11) DEFAULT NULL,
  `id_tipo_sangre` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_puesto` int(11) DEFAULT NULL,
  `id_dependencia` int(11) DEFAULT NULL,
  `id_estado_civil` int(11) DEFAULT NULL,
  `id_departamento` int(11) DEFAULT NULL,
  `id_municipio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `id` int(11) NOT NULL,
  `numero` varchar(100) NOT NULL,
  `id_tipo_documento` int(11) DEFAULT NULL,
  `id_detalle` int(11) NOT NULL,
  `id_institucion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `documentos_view`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `documentos_view` (
`id_emp` int(11)
,`codigo_empleado` varchar(100)
,`id_detalle` int(11)
,`id_doc` int(11)
,`num_doc` varchar(100)
,`id_tipo` int(11)
,`tipo_doc` varchar(100)
,`id_instit` int(11)
,`instituc` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `codigo_empleado` varchar(100) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `apellidos` varchar(200) NOT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `dui` varchar(100) NOT NULL,
  `salario` double NOT NULL,
  `nombre_contacto` varchar(300) DEFAULT NULL,
  `telefono_contacto` varchar(100) DEFAULT NULL,
  `parentesco_contacto` varchar(100) DEFAULT NULL,
  `fecha_contratacion` date NOT NULL,
  `fecha_terminacion` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `sexo` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `empleados_view`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `empleados_view` (
`id` int(11)
,`codigo_empleado` varchar(100)
,`nombre` varchar(200)
,`apellidos` varchar(200)
,`fecha_nacimiento` date
,`sexo` varchar(100)
,`estado_civil` varchar(100)
,`tipo_sanguineo` varchar(100)
,`estado_empl` tinyint(1)
,`dui` varchar(100)
,`departamento` varchar(191)
,`municipio` varchar(191)
,`direccion` varchar(100)
,`Tipo_contratacion` varchar(100)
,`fecha_contratacion` date
,`fecha_terminacion` varchar(100)
,`dependencia` varchar(100)
,`puesto` varchar(100)
,`salario` double
,`telefono` varchar(100)
,`correo` varchar(100)
,`nombre_contacto` varchar(300)
,`telefono_contacto` varchar(100)
,`parentesco_contacto` varchar(100)
,`id_detalle` int(11)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_civil`
--

CREATE TABLE `estado_civil` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estado_civil`
--

INSERT INTO `estado_civil` (`id`, `nombre`) VALUES
(1, 'Soltero/a'),
(2, 'Casado/a'),
(3, 'Viudo/a');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `institucion`
--

CREATE TABLE `institucion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `id_tipo_documento` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `institucion`
--

INSERT INTO `institucion` (`id`, `nombre`, `id_tipo_documento`) VALUES
(1, 'ISSS', 1),
(2, 'AFP Confia', 2),
(3, 'AFP Crecer', 2),
(4, 'Ministerio de Hacienda', 3),
(5, 'Banco Cuscatlan', 4),
(6, 'Banco Agricola', 4),
(7, 'Banco de America Central', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

CREATE TABLE `municipios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(191) NOT NULL,
  `id_departamento` int(10) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `municipios`
--

INSERT INTO `municipios` (`id`, `nombre`, `id_departamento`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Ahuachapán', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(2, 'Jujutla', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(3, 'Atiquizaya', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(4, 'Concepción de Ataco', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(5, 'El Refugio', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(6, 'Guaymango', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(7, 'Apaneca', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(8, 'San Francisco Menéndez', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(9, 'San Lorenzo', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(10, 'San Pedro Puxtla', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(11, 'Tacuba', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(12, 'Turín', 1, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(13, 'Candelaria de la Frontera', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(14, 'Chalchuapa', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(15, 'Coatepeque', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(16, 'El Congo', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(17, 'El Porvenir', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(18, 'Masahuat', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(19, 'Metapán', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(20, 'San Antonio Pajonal', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(21, 'San Sebastián Salitrillo', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(22, 'Santa Ana', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(23, 'Santa Rosa Guachipilín', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(24, 'Santiago de la Frontera', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(25, 'Texistepeque', 2, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(26, 'Acajutla', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(27, 'Armenia', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(28, 'Caluco', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(29, 'Cuisnahuat', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(30, 'Izalco', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(31, 'Juayúa', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(32, 'Nahuizalco', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(33, 'Nahulingo', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(34, 'Salcoatitán', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(35, 'San Antonio del Monte', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(36, 'San Julián', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(37, 'Santa Catarina Masahuat', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(38, 'Santa Isabel Ishuatán', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(39, 'Santo Domingo de Guzmán', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(40, 'Sonsonate', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(41, 'Sonzacate', 3, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(42, 'Alegría', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(43, 'Berlín', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(44, 'California', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(45, 'Concepción Batres', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(46, 'El Triunfo', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(47, 'Ereguayquín', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(48, 'Estanzuelas', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(49, 'Jiquilisco', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(50, 'Jucuapa', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(51, 'Jucuarán', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(52, 'Mercedes Umaña', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(53, 'Nueva Granada', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(54, 'Ozatlán', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(55, 'Puerto El Triunfo', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(56, 'San Agustín', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(57, 'San Buenaventura', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(58, 'San Dionisio', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(59, 'San Francisco Javier', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(60, 'Santa Elena', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(61, 'Santa María', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(62, 'Santiago de María', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(63, 'Tecapán', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(64, 'Usulután', 11, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(65, 'Carolina', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(66, 'Chapeltique', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(67, 'Chinameca', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(68, 'Chirilagua', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(69, 'Ciudad Barrios', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(70, 'Comacarán', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(71, 'El Tránsito', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(72, 'Lolotique', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(73, 'Moncagua', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(74, 'Nueva Guadalupe', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(75, 'Nuevo Edén de San Juan', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(76, 'Quelepa', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(77, 'San Antonio del Mosco', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(78, 'San Gerardo', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(79, 'San Jorge', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(80, 'San Luis de la Reina', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(81, 'San Miguel', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(82, 'San Rafael Oriente', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(83, 'Sesori', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(84, 'Uluazapa', 13, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(85, 'Arambala', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(86, 'Cacaopera', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(87, 'Chilanga', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(88, 'Corinto', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(89, 'Delicias de Concepción', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(90, 'El Divisadero', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(91, 'El Rosario (Morazán)', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(92, 'Gualococti', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(93, 'Guatajiagua', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(94, 'Joateca', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(95, 'Jocoaitique', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(96, 'Jocoro', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(97, 'Lolotiquillo', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(98, 'Meanguera', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(99, 'Osicala', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(100, 'Perquín', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(101, 'San Carlos', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(102, 'San Fernando (Morazán)', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(103, 'San Francisco Gotera', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(104, 'San Isidro (Morazán)', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(105, 'San Simón', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(106, 'Sensembra', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(107, 'Sociedad', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(108, 'Torola', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(109, 'Yamabal', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(110, 'Yoloaiquín', 12, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(111, 'La Unión', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(112, 'San Alejo', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(113, 'Yucuaiquín', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(114, 'Conchagua', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(115, 'Intipucá', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(116, 'San José', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(117, 'El Carmen (La Unión)', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(118, 'Yayantique', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(119, 'Bolívar', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(120, 'Meanguera del Golfo', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(121, 'Santa Rosa de Lima', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(122, 'Pasaquina', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(123, 'Anamoros', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(124, 'Nueva Esparta', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(125, 'El Sauce', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(126, 'Concepción de Oriente', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(127, 'Polorós', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(128, 'Lislique', 14, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(129, 'Antiguo Cuscatlán', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(130, 'Chiltiupán', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(131, 'Ciudad Arce', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(132, 'Colón', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(133, 'Comasagua', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(134, 'Huizúcar', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(135, 'Jayaque', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(136, 'Jicalapa', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(137, 'La Libertad', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(138, 'Santa Tecla', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(139, 'Nuevo Cuscatlán', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(140, 'San Juan Opico', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(141, 'Quezaltepeque', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(142, 'Sacacoyo', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(143, 'San José Villanueva', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(144, 'San Matías', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(145, 'San Pablo Tacachico', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(146, 'Talnique', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(147, 'Tamanique', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(148, 'Teotepeque', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(149, 'Tepecoyo', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(150, 'Zaragoza', 4, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(151, 'Agua Caliente', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(152, 'Arcatao', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(153, 'Azacualpa', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(154, 'Cancasque', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(155, 'Chalatenango', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(156, 'Citalá', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(157, 'Comapala', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(158, 'Concepción Quezaltepeque', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(159, 'Dulce Nombre de María', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(160, 'El Carrizal', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(161, 'El Paraíso', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(162, 'La Laguna', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(163, 'La Palma', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(164, 'La Reina', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(165, 'Las Vueltas', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(166, 'Nueva Concepción', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(167, 'Nueva Trinidad', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(168, 'Nombre de Jesús', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(169, 'Ojos de Agua', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(170, 'Potonico', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(171, 'San Antonio de la Cruz', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(172, 'San Antonio Los Ranchos', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(173, 'San Fernando (Chalatenango)', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(174, 'San Francisco Lempa', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(175, 'San Francisco Morazán', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(176, 'San Ignacio', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(177, 'San Isidro Labrador', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(178, 'Las Flores', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(179, 'San Luis del Carmen', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(180, 'San Miguel de Mercedes', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(181, 'San Rafael', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(182, 'Santa Rita', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(183, 'Tejutla', 5, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(184, 'Cojutepeque', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(185, 'Candelaria', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(186, 'El Carmen (Cuscatlán)', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(187, 'El Rosario (Cuscatlán)', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(188, 'Monte San Juan', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(189, 'Oratorio de Concepción', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(190, 'San Bartolomé Perulapía', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(191, 'San Cristóbal', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(192, 'San José Guayabal', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(193, 'San Pedro Perulapán', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(194, 'San Rafael Cedros', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(195, 'San Ramón', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(196, 'Santa Cruz Analquito', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(197, 'Santa Cruz Michapa', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(198, 'Suchitoto', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(199, 'Tenancingo', 7, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(200, 'Aguilares', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(201, 'Apopa', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(202, 'Ayutuxtepeque', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(203, 'Cuscatancingo', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(204, 'Ciudad Delgado', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(205, 'El Paisnal', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(206, 'Guazapa', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(207, 'Ilopango', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(208, 'Mejicanos', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(209, 'Nejapa', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(210, 'Panchimalco', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(211, 'Rosario de Mora', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(212, 'San Marcos', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(213, 'San Martín', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(214, 'San Salvador', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(215, 'Santiago Texacuangos', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(216, 'Santo Tomás', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(217, 'Soyapango', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(218, 'Tonacatepeque', 6, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(219, 'Zacatecoluca', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(220, 'Cuyultitán', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(221, 'El Rosario (La Paz)', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(222, 'Jerusalén', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(223, 'Mercedes La Ceiba', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(224, 'Olocuilta', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(225, 'Paraíso de Osorio', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(226, 'San Antonio Masahuat', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(227, 'San Emigdio', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(228, 'San Francisco Chinameca', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(229, 'San Pedro Masahuat', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(230, 'San Juan Nonualco', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(231, 'San Juan Talpa', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(232, 'San Juan Tepezontes', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(233, 'San Luis La Herradura', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(234, 'San Luis Talpa', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(235, 'San Miguel Tepezontes', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(236, 'San Pedro Nonualco', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(237, 'San Rafael Obrajuelo', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(238, 'Santa María Ostuma', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(239, 'Santiago Nonualco', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(240, 'Tapalhuaca', 8, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(241, 'Cinquera', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(242, 'Dolores', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(243, 'Guacotecti', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(244, 'Ilobasco', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(245, 'Jutiapa', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(246, 'San Isidro (Cabañas)', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(247, 'Sensuntepeque', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(248, 'Tejutepeque', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(249, 'Victoria', 9, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(250, 'Apastepeque', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(251, 'Guadalupe', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(252, 'San Cayetano Istepeque', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(253, 'San Esteban Catarina', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(254, 'San Ildefonso', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(255, 'San Lorenzo', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(256, 'San Sebastián', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(257, 'San Vicente', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(258, 'Santa Clara', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(259, 'Santo Domingo', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(260, 'Tecoluca', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(261, 'Tepetitán', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57'),
(262, 'Verapaz', 10, NULL, NULL, '2023-04-17 13:05:57', '2023-04-17 13:05:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puestos`
--

CREATE TABLE `puestos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `id_dependencia` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_contrato`
--

CREATE TABLE `tipo_contrato` (
  `id` int(11) NOT NULL,
  `tipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_contrato`
--

INSERT INTO `tipo_contrato` (`id`, `tipo`) VALUES
(1, 'Tiempo indefinido'),
(2, 'Período determinado'),
(3, 'Servicios profesionales');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_documento`
--

CREATE TABLE `tipo_documento` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_documento`
--

INSERT INTO `tipo_documento` (`id`, `nombre`) VALUES
(1, 'Carnet ISSS'),
(2, 'NUP'),
(3, 'NIT'),
(4, 'Cuenta de Ahorro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_sangre`
--

CREATE TABLE `tipo_sangre` (
  `id` int(11) NOT NULL,
  `tipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_sangre`
--

INSERT INTO `tipo_sangre` (`id`, `tipo`) VALUES
(1, 'AB+'),
(2, 'AB-'),
(3, 'O+'),
(4, 'O-'),
(5, 'A+'),
(6, 'A-'),
(7, 'B+'),
(8, 'B-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `estado`) VALUES
(1, 'admin', 'XoszCrYiIrk=', 1);

-- --------------------------------------------------------

--
-- Estructura para la vista `documentos_view`
--
DROP TABLE IF EXISTS `documentos_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `documentos_view`  AS SELECT `emp`.`id` AS `id_emp`, `emp`.`codigo_empleado` AS `codigo_empleado`, `det`.`id` AS `id_detalle`, `doc`.`id` AS `id_doc`, `doc`.`numero` AS `num_doc`, `td`.`id` AS `id_tipo`, `td`.`nombre` AS `tipo_doc`, `ins`.`id` AS `id_instit`, `ins`.`nombre` AS `instituc` FROM ((((`empleados` `emp` left join `detalle_empleado` `det` on(`det`.`id_empleado` = `emp`.`id`)) left join `documentos` `doc` on(`det`.`id` = `doc`.`id_detalle`)) left join `tipo_documento` `td` on(`doc`.`id_tipo_documento` = `td`.`id`)) left join `institucion` `ins` on(`doc`.`id_institucion` = `ins`.`id`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `empleados_view`
--
DROP TABLE IF EXISTS `empleados_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `empleados_view`  AS SELECT `emp`.`id` AS `id`, `emp`.`codigo_empleado` AS `codigo_empleado`, `emp`.`nombre` AS `nombre`, `emp`.`apellidos` AS `apellidos`, `emp`.`fecha_nacimiento` AS `fecha_nacimiento`, `emp`.`sexo` AS `sexo`, `estciv`.`nombre` AS `estado_civil`, `sangre`.`tipo` AS `tipo_sanguineo`, `emp`.`estado` AS `estado_empl`, `emp`.`dui` AS `dui`, `dep`.`nombre` AS `departamento`, `mun`.`nombre` AS `municipio`, `emp`.`direccion` AS `direccion`, `tipcon`.`tipo` AS `Tipo_contratacion`, `emp`.`fecha_contratacion` AS `fecha_contratacion`, `emp`.`fecha_terminacion` AS `fecha_terminacion`, `depend`.`nombre` AS `dependencia`, `puest`.`nombre` AS `puesto`, `emp`.`salario` AS `salario`, `emp`.`telefono` AS `telefono`, `emp`.`correo` AS `correo`, `emp`.`nombre_contacto` AS `nombre_contacto`, `emp`.`telefono_contacto` AS `telefono_contacto`, `emp`.`parentesco_contacto` AS `parentesco_contacto`, `det`.`id` AS `id_detalle` FROM ((((((((`empleados` `emp` left join `detalle_empleado` `det` on(`det`.`id_empleado` = `emp`.`id`)) left join `estado_civil` `estciv` on(`det`.`id_estado_civil` = `estciv`.`id`)) left join `tipo_sangre` `sangre` on(`det`.`id_tipo_sangre` = `sangre`.`id`)) left join `departamentos` `dep` on(`det`.`id_departamento` = `dep`.`id`)) left join `municipios` `mun` on(`det`.`id_municipio` = `mun`.`id`)) left join `tipo_contrato` `tipcon` on(`det`.`id_tipo_contratacion` = `tipcon`.`id`)) left join `dependencia` `depend` on(`det`.`id_dependencia` = `depend`.`id`)) left join `puestos` `puest` on(`det`.`id_puesto` = `puest`.`id`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `dependencia`
--
ALTER TABLE `dependencia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indices de la tabla `detalle_empleado`
--
ALTER TABLE `detalle_empleado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_dependencia` (`id_dependencia`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_municipio` (`id_municipio`),
  ADD KEY `id_departamento` (`id_departamento`),
  ADD KEY `id_tipo_sangre` (`id_tipo_sangre`),
  ADD KEY `id_estado_civil` (`id_estado_civil`),
  ADD KEY `id_tipo_contratacion` (`id_tipo_contratacion`),
  ADD KEY `id_puesto` (`id_puesto`) USING BTREE,
  ADD KEY `id_empleado` (`id_empleado`) USING BTREE;

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_tipo_documento` (`id_tipo_documento`),
  ADD KEY `documentos_id_detalle_IDX` (`id_detalle`) USING BTREE,
  ADD KEY `id_detalle` (`id_detalle`),
  ADD KEY `documentos_ibfk_3` (`id_institucion`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_civil`
--
ALTER TABLE `estado_civil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `institucion`
--
ALTER TABLE `institucion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_tipo_documento` (`id_tipo_documento`);

--
-- Indices de la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `puestos`
--
ALTER TABLE `puestos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_dependencia` (`id_dependencia`);

--
-- Indices de la tabla `tipo_contrato`
--
ALTER TABLE `tipo_contrato`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_documento`
--
ALTER TABLE `tipo_documento`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_sangre`
--
ALTER TABLE `tipo_sangre`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `dependencia`
--
ALTER TABLE `dependencia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle_empleado`
--
ALTER TABLE `detalle_empleado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `documentos`
--
ALTER TABLE `documentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estado_civil`
--
ALTER TABLE `estado_civil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `institucion`
--
ALTER TABLE `institucion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `municipios`
--
ALTER TABLE `municipios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=263;

--
-- AUTO_INCREMENT de la tabla `puestos`
--
ALTER TABLE `puestos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_contrato`
--
ALTER TABLE `tipo_contrato`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_documento`
--
ALTER TABLE `tipo_documento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tipo_sangre`
--
ALTER TABLE `tipo_sangre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `dependencia`
--
ALTER TABLE `dependencia`
  ADD CONSTRAINT `dependencia_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_empleado`
--
ALTER TABLE `detalle_empleado`
  ADD CONSTRAINT `detalle_empleado_ibfk_1` FOREIGN KEY (`id_dependencia`) REFERENCES `dependencia` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_empleado_ibfk_10` FOREIGN KEY (`id_puesto`) REFERENCES `puestos` (`id`),
  ADD CONSTRAINT `detalle_empleado_ibfk_11` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_empleado_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `detalle_empleado_ibfk_3` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_empleado_ibfk_4` FOREIGN KEY (`id_municipio`) REFERENCES `municipios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_empleado_ibfk_5` FOREIGN KEY (`id_estado_civil`) REFERENCES `estado_civil` (`id`),
  ADD CONSTRAINT `detalle_empleado_ibfk_6` FOREIGN KEY (`id_tipo_sangre`) REFERENCES `tipo_sangre` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_empleado_ibfk_7` FOREIGN KEY (`id_tipo_contratacion`) REFERENCES `tipo_contrato` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `documentos_ibfk_1` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tipo_documento` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `documentos_ibfk_2` FOREIGN KEY (`id_detalle`) REFERENCES `detalle_empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `documentos_ibfk_3` FOREIGN KEY (`id_institucion`) REFERENCES `institucion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `institucion`
--
ALTER TABLE `institucion`
  ADD CONSTRAINT `institucion_ibfk_1` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tipo_documento` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `puestos`
--
ALTER TABLE `puestos`
  ADD CONSTRAINT `puestos_ibfk_1` FOREIGN KEY (`id_dependencia`) REFERENCES `dependencia` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
